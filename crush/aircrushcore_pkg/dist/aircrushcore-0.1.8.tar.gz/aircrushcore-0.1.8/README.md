# coreCRUSH Package

Core Package for client integration with AirCrush neuroscience workflow platform