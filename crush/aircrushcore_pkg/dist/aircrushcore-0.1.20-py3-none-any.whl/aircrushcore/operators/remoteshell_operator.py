from .base_operator import BaseOperator

class RemoteShell(BaseOperator):
    
    def __init__(self,**kwargs):        
        super().__init__()
        
    def execute(self):
        pass
