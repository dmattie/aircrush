from .base_operator import BaseOperator

class HCPSlurmJob(BaseOperator):
    
   # def __init__(self,id,**kwargs):        
   #     pass#super().__init__()
        
    def execute(self):
        pass
