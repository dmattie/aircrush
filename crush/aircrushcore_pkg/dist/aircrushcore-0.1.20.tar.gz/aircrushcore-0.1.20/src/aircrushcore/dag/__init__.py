from aircrushcore.dag.workload import Workload

__all__ = ("Workload")