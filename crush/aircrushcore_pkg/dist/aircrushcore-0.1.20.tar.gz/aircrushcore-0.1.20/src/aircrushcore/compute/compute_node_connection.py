class ComputeNodeConnection():  

    def __init__(self,hostname:str,username:str,password:str,working_directory:str):

        self.hostname = hostname
        self.username = username
        self.password = password
        self.working_directory=working_directory


            
